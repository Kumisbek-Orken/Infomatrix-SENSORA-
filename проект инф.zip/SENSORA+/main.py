import cv2
import threading
import numpy as np
import time
import os
import config
from vision import ObjectDetector
from voice import VoiceAssistant
from gesture import GestureRecognizer
from listener import SpeechListener

last_frame = None
last_results = None
running = True
chat_history = []
current_mode = "1"

def ai_worker(detector):
    global last_frame, last_results, running, current_mode
    while running:
        if current_mode == "1" and last_frame is not None:
            last_results = detector.detect(last_frame)
        time.sleep(0.01)

def run_app():
    global last_frame, last_results, running, current_mode
    
    print("\n1-BLIND | 2-DEAF | 3-MUTE")
    current_mode = input("Mode: ")

    cap = cv2.VideoCapture(config.CAMERA_SOURCE)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    detector = ObjectDetector()
    voice = VoiceAssistant()
    hand_rec = GestureRecognizer()
    listener = SpeechListener()

    if current_mode == "1":
        threading.Thread(target=ai_worker, args=(detector,), daemon=True).start()
    elif current_mode == "2":
        def speech_bg():
            while running:
                t = listener.listen()
                if t: chat_history.append(t)
        threading.Thread(target=speech_bg, daemon=True).start()

    last_voice_time = 0

    while True:
        success, frame = cap.read()
        if not success: continue

        frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
        last_frame = frame.copy()

        if current_mode == "1":
            if isinstance(last_results, list):
                for obj in last_results[:3]:
                    x, y, w, h = obj['box']
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    cv2.putText(frame, f"{obj['label']} {obj['dist']}m", (x, y-10), 1, 1, (0, 255, 0), 2)
                if time.time() - last_voice_time > 3 and last_results:
                    voice.say(f"{last_results[0]['label']} {last_results[0]['pos']}")
                    last_voice_time = time.time()

        elif current_mode == "2":
            sub_frame = np.zeros((600, 400, 3), dtype=np.uint8)
            for i, txt in enumerate(chat_history[-10:]):
                cv2.putText(sub_frame, txt, (20, 550 - i*40), 1, 1.2, (255, 255, 255), 2)
            cv2.imshow("EchoVision", sub_frame)
            if cv2.waitKey(1) & 0xFF == ord('q'): break
            continue

        elif current_mode == "3":
            # Квадрат (поставь такие цифры, чтобы рука влезала!)
            x1, y1, x2, y2 = 50, 50, 350, 350 
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            
            roi = frame[y1:y2, x1:x2].copy()
            # ПРЯМОЙ ВЫЗОВ
            processed_roi, gesture_name = hand_rec.process_frame(roi)
            
            # Возвращаем картинку с точками на экран
            frame[y1:y2, x1:x2] = processed_roi
            cv2.putText(frame, f"GESTURE: {gesture_name}", (20, 450), 2, 1, (0, 255, 0), 2)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('c'):
                hand_rec.calibrate(frame[y1:y2, x1:x2])
            elif key == ord('q'): break

        cv2.imshow("EchoVision Pro", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'): break

    running = False
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_app()