import cv2
import numpy as np
import math

class GestureRecognizer:
    def __init__(self):
        # Начальные настройки (по умолчанию)
        self.lower_skin = np.array([0, 20, 70], dtype=np.uint8)
        self.upper_skin = np.array([20, 255, 255], dtype=np.uint8)
        self.calibrated = False

    def calibrate(self, roi):
        hsv_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        mean_color = np.mean(hsv_roi, axis=(0, 1))
        h_val = mean_color[0]
        self.lower_skin = np.array([max(0, h_val - 25), 50, 60], dtype=np.uint8)
        self.upper_skin = np.array([min(180, h_val + 25), 255, 255], dtype=np.uint8)
        self.calibrated = True
        print("Calibrated!")

    def process_frame(self, roi):
        if not self.calibrated:
            return roi, "PRESS C"

        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.lower_skin, self.upper_skin)
        mask = cv2.GaussianBlur(mask, (5, 5), 0)
        
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        gesture_text = "..."

        if len(contours) > 0:
            cnt = max(contours, key=lambda x: cv2.contourArea(x))
            if cv2.contourArea(cnt) > 1000:
                cv2.drawContours(roi, [cnt], -1, (255, 0, 0), 2) # Синий контур
                hull = cv2.convexHull(cnt, returnPoints=False)
                
                try:
                    defects = cv2.convexityDefects(cnt, hull)
                    count_fingers = 0
                    if defects is not None:
                        for i in range(defects.shape[0]):
                            s, e, f, d = defects[i, 0]
                            start = tuple(cnt[s][0])
                            end = tuple(cnt[e][0])
                            far = tuple(cnt[f][0])
                            
                            a = math.sqrt((end[0]-start[0])**2 + (end[1]-start[1])**2)
                            b = math.sqrt((far[0]-start[0])**2 + (far[1]-start[1])**2)
                            c = math.sqrt((end[0]-far[0])**2 + (far[1]-far[1])**2)
                            angle = math.acos((b**2 + c**2 - a**2)/(2*b*c)) * 57
                            
                            if angle <= 90:
                                count_fingers += 1
                                cv2.circle(roi, far, 5, [0, 0, 255], -1) # Красные точки
                            cv2.line(roi, start, end, [0, 255, 0], 2) # Зеленые линии

                    # Твои жесты
                    res = {0: "FIST", 1: "TWO", 2: "THREE", 3: "FOUR", 4: "HELLO"}
                    gesture_text = res.get(count_fingers, "WAIT")
                except:
                    pass
        return roi, gesture_text