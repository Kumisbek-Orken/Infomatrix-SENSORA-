import speech_recognition as sr
import cv2

class SpeechListener:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.mic = sr.Microphone()

    def wrap_text(self, text, max_width, font, font_scale, thickness):
        lines = []
        current_line = ""
        words = text.split(' ')
        for word in words:
            (word_w, _), _ = cv2.getTextSize(word, font, font_scale, thickness)
            if word_w > max_width:
                if current_line: lines.append(current_line.strip())
                current_line = ""
                for char in word:
                    (test_w, _), _ = cv2.getTextSize(current_line + char, font, font_scale, thickness)
                    if test_w < max_width: current_line += char
                    else:
                        lines.append(current_line.strip())
                        current_line = char
                current_line += " "
            else:
                test_line = current_line + word + " "
                (line_w, _), _ = cv2.getTextSize(test_line, font, font_scale, thickness)
                if line_w < max_width: current_line = test_line
                else:
                    lines.append(current_line.strip())
                    current_line = word + " "
        if current_line: lines.append(current_line.strip())
        return lines

    def listen(self):
        try:
            with self.mic as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = self.recognizer.listen(source, phrase_time_limit=5)
            return self.recognizer.recognize_google(audio, language="ru-RU")
        except:
            return None