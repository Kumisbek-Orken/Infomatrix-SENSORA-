# Источник камеры (0 - стандартная веб-камера, 1 - внешняя)
CAMERA_SOURCE ="http://192.168.1.229:8080/video"

# Настройки для YOLO
MODEL_PATH = "yolov8n.pt"
CONFIDENCE_THRESHOLD = 0.3

# Если у тебя камера перевернута, можно добавить флаг здесь
ROTATE_CAMERA = False