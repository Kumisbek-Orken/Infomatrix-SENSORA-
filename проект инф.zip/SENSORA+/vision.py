from ultralytics import YOLO
import config

class ObjectDetector:
    def __init__(self):
        self.model = YOLO("yolov8n.pt") 

    def detect(self, frame):
        # Оставляем imgsz=160 для скорости на твоем ПК
        results = self.model(frame, imgsz=160, conf=0.3, verbose=False, stream=True)
        
        processed_results = []
        for r in results:
            boxes = r.boxes[:3] 
            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                cls = int(box.cls[0])
                label = self.model.names[cls]
                
                w = x2 - x1
                h = y2 - y1
                center_x = x1 + (w / 2)
                width = frame.shape[1]

                # Определение позиции
                if center_x < width/3: pos = "слева"
                elif center_x > width*2/3: pos = "справа"
                else: pos = "прямо"

                h = y2 - y1
                
                # Коэффициент калибровки для метров. 
                # Если 20 см — это 0.2, попробуй коэффициент 0.15
                calib_factor = 0.15 
                
                # Считаем метры. Округляем до 1 знака после запятой (например, 0.3)
                dist_m = round((calib_factor * 1000) / (h + 1), 1)

                processed_results.append({
                    "label": label,
                    "box": [int(x1), int(y1), int(w), int(h)],
                    "pos": pos,
                    "dist": dist_m 
                })

                processed_results.append({
                    "label": label,
                    "box": [int(x1), int(y1), int(w), int(h)],
                    "pos": pos,
                    "dist": dist_m
                })
        return processed_results