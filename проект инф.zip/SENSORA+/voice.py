import os

class VoiceAssistant:
    def __init__(self):
        pass

    def say(self, text):
        # Твой оригинальный метод через PowerShell
        # start /B запускает процесс в фоновом режиме, чтобы видео не фризило
        cmd = f'PowerShell -Command "Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak(\'{text}\')"'
        os.system(f'start /B {cmd}')